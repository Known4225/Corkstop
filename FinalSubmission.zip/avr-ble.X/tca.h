#ifndef __TCA_H_
#define __TCA_H_

#include "ecode.h"

ECODE tca_init();

#endif /* __TCA_H_ */
